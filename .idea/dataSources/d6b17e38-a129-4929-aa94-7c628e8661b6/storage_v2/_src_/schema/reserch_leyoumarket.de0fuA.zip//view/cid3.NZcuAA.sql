create view cid3 as
  select `reserch_leyoumarket`.`tb_category`.`parent_id` AS `parent_id`
  from `reserch_leyoumarket`.`tb_category`
  group by `reserch_leyoumarket`.`tb_category`.`parent_id`;

